package atividade.pkg04;

public interface Imposto {

    double calcularImposto();

    String getDescricao();
}
